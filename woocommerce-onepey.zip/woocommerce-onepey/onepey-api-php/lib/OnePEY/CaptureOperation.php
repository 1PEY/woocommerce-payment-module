<?php
namespace OnePEY;

class CaptureOperation extends ChildTransaction {
}
?>

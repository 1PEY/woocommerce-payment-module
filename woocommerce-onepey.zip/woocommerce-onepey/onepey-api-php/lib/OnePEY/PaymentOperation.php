<?php
namespace OnePEY;

class PaymentOperation extends AuthorizationOperation {
}
?>

<?php
namespace OnePEY;

class PaymentHostedPageOperation extends AuthorizationHostedPageOperation {
}
?>

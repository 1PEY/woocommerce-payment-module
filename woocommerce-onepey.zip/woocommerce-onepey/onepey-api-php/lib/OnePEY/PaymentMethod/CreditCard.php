<?php
namespace OnePEY\PaymentMethod;

class CreditCard extends Base {
}
?>
